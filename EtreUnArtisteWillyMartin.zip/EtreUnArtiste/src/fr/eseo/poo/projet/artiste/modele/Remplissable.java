package fr.eseo.poo.projet.artiste.modele;

public interface Remplissable {

	public boolean estRempli();
	public void setRempli(boolean modeRemplissage);
}
