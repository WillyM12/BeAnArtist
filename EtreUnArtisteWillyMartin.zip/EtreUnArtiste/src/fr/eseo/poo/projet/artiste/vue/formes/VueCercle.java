package fr.eseo.poo.projet.artiste.vue.formes;

import fr.eseo.poo.projet.artiste.modele.formes.Cercle;

public class VueCercle extends VueEllipse {
	
	public VueCercle(Cercle cercle) {
		super(cercle);
	}
}
