package fr.eseo.poo.projet.artiste.modele.formes;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

/**
 * Classe de test paramétrée, via la technique du constructeur, de la classe Ellipse.
 * 
 * @author Willy MArtin
 * @version 1.0
 *
 */
@RunWith(Parameterized.class)
public class EllipseTestPerimetreParameterized {
	
	private static final double EPSILON = 1e-3d;
	
	private double largeur;
	private double hauteur;
	private double perimetreAttendu;

	private Ellipse e1;
	
	public EllipseTestPerimetreParameterized(double largeur, double hauteur, double perimetreAttendu) {
		this.hauteur = hauteur;
		this.largeur = largeur;
		this.perimetreAttendu = perimetreAttendu;
	}
	
	/**
	 * Création du jeu de test. 
	 * 
	 * @return l'ensemble des données de test. 
	 */
	@Parameters(name = "dt[{index}] : {0}, {1}, {2}") 
    public static Collection<Object[]> dt() {
        Object[][] data = new Object[][] { 
        	{1,1,Math.PI},
        	{2,1,4.844},
        	{1,2,4.844},
        	{2.45,1.34,6.082},
        };
        return Arrays.asList(data);
    }
	
	@Before
    public void setUp() {
    	e1 = new Ellipse(largeur, hauteur);
    }
    
	/**
	 * Test de la méthode perimetre() de Ellipse.
	 */
	@Test
	public void testgetType() {
		assertEquals("Test de la methode perimetre de Ellipse", perimetreAttendu, e1.perimetre(), EPSILON);
	}
	
}
