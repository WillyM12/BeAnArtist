package fr.eseo.poo.projet.artiste.modele.formes;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

/**
 * Classe de test paramétrée, via la technique du constructeur, de la classe Ellipse.
 * 
 * @author Willy MArtin
 * @version 1.0
 *
 */
@RunWith(Parameterized.class)

public class EllipseTestAireParameterized {

private static final double EPSILON = 1e-3d;
	
	private double largeur;
	private double hauteur;
	private double aireAttendu;

	private Ellipse e1;
	
	public EllipseTestAireParameterized(double largeur, double hauteur, double aireAttendu) {
		this.hauteur = hauteur;
		this.largeur = largeur;
		this.aireAttendu = aireAttendu;
	}
	
	/**
	 * Création du jeu de test. 
	 * 
	 * @return l'ensemble des données de test. 
	 */
	@Parameters(name = "dt[{index}] : {0}, {1}, {2}") 
    public static Collection<Object[]> dt() {
        Object[][] data = new Object[][] { 
        	{1,1,Math.PI/4},
        	{2,1,Math.PI/2},
        	{1,2,Math.PI/2},
        	{2.45,1.34,2.578},
        };
        return Arrays.asList(data);
    }
	
	@Before
    public void setUp() {
    	e1 = new Ellipse(largeur, hauteur);
    }
    
	/**
	 * Test de la méthode aire() de Ellipse.
	 */
	@Test
	public void testgetType() {
		assertEquals("Test de la methode aire de Ellipse", aireAttendu, e1.aire(), EPSILON);
	}
}
